This contains the minimal set of jars from mockrunner-0.4.1 to run the modjy tests against j2ee1.3
with jdk1.5.
